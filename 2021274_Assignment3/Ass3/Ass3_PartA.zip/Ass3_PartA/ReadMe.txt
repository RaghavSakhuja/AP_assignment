Part_A

Raghav Sakhuja
2021274

Documentation

How to run:

pom.xml file would be available in the Ass3_PartA folder.

Import the maven project and execute the main class in Ass3_PartA/src/main/java/rag.sakhuja .

Output:

Running the code would give the required outputs.
It is recommended to reduce the background process as much as possible and run the code multiple times to get the idea of general trend of output and randomness in input generation and background can result in varied values.
The trace file called trace.txt will be generated and stored in the Ass3_partA folder.
The result of parallel and nonParallel sorting is saved in Parallel.txt and NonParallel.txt in Ass3_PartA folder

Explanations:

The code handles a generic Array which is sorted with and without parallelization using the odd even sort. The arrays of size have 2 threads, while the array with size 1 does not implement parallelization. Ie only a single thread is used.
The actual time difference is only visible for larger arrays as the overhead of creating threads might be larger than the time they save.
