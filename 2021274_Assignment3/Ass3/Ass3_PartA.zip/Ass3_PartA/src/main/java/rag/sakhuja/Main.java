package rag.sakhuja;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {
        ArrayList<Double> CGPA2 = new ArrayList<Double>();
        ArrayList<Double> CGPA3 = new ArrayList<Double>();
        ArrayList<Double> CGPA1 = new ArrayList<Double>();
        ArrayList<Double> parallelTrace = new ArrayList<Double>();
        ArrayList<Double> nonParallelTrace = new ArrayList<Double>();
        ArrayList<Integer> n=new ArrayList<>();
        n.add(1);n.add(10);n.add(100);n.add(1000);n.add(10000);n.add(1000000);
        ArrayList<Integer> threadnum=new ArrayList<>();
        threadnum.add(1);threadnum.add(2);threadnum.add(2);threadnum.add(2);threadnum.add(4);threadnum.add(5);
        SortArrs<Double> Parallel=new SortArrs<Double>();
        SortArrs<Double> NonParallel=new SortArrs<Double>();

        for(int j=0;j<5;j++) {
            for (int i = 0; i < n.get(j); i++) {
                int a = (int) (Math.random()*1000);
                double b = a / 1000.0;
                CGPA1.add(b);
                CGPA2.add(b);
                CGPA3.add(b);
            }
            Collections.sort(CGPA3);
            Collections.reverse(CGPA3);

            Double t1=sortNonParallel_segment(CGPA1, CGPA3,NonParallel);
            Double t2=sortParallel_segment(CGPA2, threadnum.get(j), CGPA3,Parallel);
            nonParallelTrace.add(t1);
            parallelTrace.add(t2);
            CGPA1.clear();
            CGPA2.clear();
            CGPA3.clear();
            System.out.println("Clear " + j);
        }
        NonParallel.DumpArrs("NonParallel.txt");
        Parallel.DumpArrs("Parallel.txt");
        PrintFile("Trace.txt","Threads used are 2 for all lists except with size 1" +
                "\nLength of Arrays : "+n+
                "\nParallelized(ms) : "+parallelTrace+
                " \nNon Parallel(ms) : "+nonParallelTrace);

    }

    public  static void PrintFile(String PathName,Object a) throws IOException {
        PrintWriter out=null;
        try{
            out=new PrintWriter( new FileWriter(PathName));
            out.println(a);
        }finally {
            if(out!=null){
                out.close();
            }
        }

    }

    private static Double sortNonParallel_segment(ArrayList<Double> cgpa1, ArrayList<Double> cgpa3, SortArrs sortedArrs) throws InterruptedException {
        int n=cgpa1.size();
        Instant start = Instant.now();
        ArrSort a=new ArrSort<Double>(cgpa1);
        Thread t=new Thread(a);
        t.start();
        t.join();
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toNanos();
//        System.out.println(a.getCG());
        sortedArrs.addArr(a.getCG());
        if(cgpa3.equals(a.getCG())){
            System.out.println("Array is Sorted");
            System.out.println(timeElapsed/1000000.0 + " ms to sort array of "+n+" without Parallelization");
            return timeElapsed/1000000.0;
        }
        else {
            System.out.println("Not Sorted");
            return -1.0;
        }
    }

    private static Double sortParallel_segment(ArrayList<Double> cgpa2, Integer threadnum, ArrayList<Double> cgpa3, SortArrs sortedArrs) throws InterruptedException {
        int n=cgpa2.size();
        ArrayList<Thread> threadArrayList=new ArrayList<Thread>();
        ArrayList<ArrSort<Double>> arrSortArrayList=new ArrayList<ArrSort<Double>>();
        for(int i=0;i<threadnum;i++){
            int st = (i * n / threadnum);
            int end = (i + 1) * n / threadnum;
            ArrayList<Double> term=new ArrayList<>(cgpa2.subList(st,end));
            ArrSort t=new ArrSort(term);
            arrSortArrayList.add(t);
            Thread th=new Thread(t);
            threadArrayList.add(th);
        }
        Instant start = Instant.now();

        for(int i=0;i<threadArrayList.size();i++){
            threadArrayList.get(i).start();
        }
        for(int i=0;i<threadArrayList.size();i++){
            threadArrayList.get(i).join();
        }
        ArrayList<Double> half_half=new ArrayList<Double>();
        for(int i=0;i<threadnum;i++){
            ArrayList<Double> term=arrSortArrayList.get(i).getCG();
            half_half.addAll(term);
        }
        ArrSort a=new ArrSort(half_half);
        Thread t=new Thread(a);
        t.start();
        t.join();
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toNanos();
        sortedArrs.addArr(a.getCG());
        if(cgpa3.equals(a.getCG())){
            System.out.println("Array is Sorted");
            System.out.println(timeElapsed/1000000.0 + " ms to sort array of "+n+" with "+threadnum+" threads ie with Parallelization ");
            return timeElapsed/1000000.0;

        }
        else {
            System.out.println("Not Sorted");
            return -1.0;
        }
    }
}