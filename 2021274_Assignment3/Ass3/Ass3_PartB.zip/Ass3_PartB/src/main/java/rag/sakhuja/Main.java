package rag.sakhuja;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;

import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.lang.Thread.sleep;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        ArrayList<Integer> randomArray1 = new ArrayList<Integer>();
        ArrayList<Integer> randomArray2 = new ArrayList<Integer>();
        ArrayList<Integer> randomArray3 = new ArrayList<Integer>();
        ArrayList<Double> RtwoThread = new ArrayList<Double>();
        ArrayList<Double> RfourThread = new ArrayList<Double>();
        ArrayList<Double> RnoThread = new ArrayList<Double>();
        ArrayList<Double> StwoThread = new ArrayList<Double>();
        ArrayList<Double> SfourThread = new ArrayList<Double>();
        ArrayList<Double> SnoThread = new ArrayList<Double>();
        ArrayList<Integer> n = new ArrayList<>();
        n.add(10);
        n.add(1000);
        n.add(100000);
        n.add(1000000);
        for (int j = 0; j < 4; j++) {
            for (int i = 0; i < n.get(j); i++) {
                int a = (int) ((Math.random() - 0.5) * 2 * 1e9);
                randomArray1.add(a);
                randomArray2.add(a);
                randomArray3.add(a);
            }
//            int searchNum=randomArray1.get((int)(Math.random()*n.get(j)));
            int searchNum=randomArray1.get(n.get(j)-(int)(Math.random()*10));
//            System.out.println(randomArray1);
            int len=n.get(j);
            Tree tree1=new Tree(len);
            Tree tree2=new Tree(len);
            Tree tree3=new Tree(len);
            sleep(1000);
            Double t1=run1threads(randomArray1,tree1,len);
            Double t2=run2threads(randomArray2,tree2,len);
            Double t3=run4threads(randomArray3,tree3,len);
//            if(tree1.toString().equals(tree2.toString())){
//                System.out.println("Pencho");
//            }
//            if(tree1.toString().equals(tree3.toString())){
//                System.out.println("Pencho");
//            }
            RtwoThread.add(t2);
            RnoThread.add(t1);
            RfourThread.add(t3);
            Double ts1=search1thread(tree1,searchNum,randomArray1);
            Double ts2=search2thread(tree1,searchNum,randomArray2);
            Double ts3=search4thread(tree1,searchNum,randomArray3);
            StwoThread.add(ts2);
            SnoThread.add(ts1);
            SfourThread.add(ts3);
            randomArray1.clear();
            randomArray2.clear();
            randomArray3.clear();
        }
        PrintFile("Trace.txt","The size of trees is: "+n+
                "\nTime to create tree: "+
                "\nNo Thread: "+RnoThread+
                "\n2 Threads: "+RtwoThread+
                "\n4 Threads: "+RfourThread+
                "\nTime to search an element: "+
                "\nNo Thread: "+SnoThread+
                "\n2 Threads: "+StwoThread+
                "\n4 Threads: "+SfourThread);

    }
    public  static void PrintFile(String PathName,Object a) throws IOException {
        PrintWriter out=null;
        try{
            out=new PrintWriter( new FileWriter(PathName));
            out.println(a);
        }finally {
            if(out!=null){
                out.close();
            }
        }

    }

    private static Double search1thread(Tree tree1, int searchNum, ArrayList<Integer> randomArray1) throws InterruptedException {

        CreateTree ct=new CreateTree(tree1,randomArray1,0,false);
        ct.setSearchable(searchNum);
        Thread th1=new Thread(ct);
        Instant start=Instant.now();
        th1.start();
        th1.join();
        Instant finish=ct.getFinish();
        long timeElapsed = Duration.between(start, finish).toNanos();
//        System.out.println(timeElapsed);
        System.out.println(timeElapsed/1000000.0 + " ms to find an element using 1 threads");
        return timeElapsed/1000000.0;

    }
    private static Double search2thread(Tree tree1, int searchNum, ArrayList<Integer> randomArray2) throws InterruptedException {
        Instant st1=Instant.now();
        int t1=tree1.getNode(0).getVal();
        if(t1!=searchNum){
            CreateTree ct=new CreateTree(tree1,randomArray2,1,false);
            CreateTree ct2=new CreateTree(tree1,randomArray2,2,false);
            ct.setSearchable(searchNum);
            ct2.setSearchable(searchNum);
            Thread th1=new Thread(ct);
            Thread th2=new Thread(ct2);
            Instant start=Instant.now();
            th1.start();
            th2.start();
            th1.join();
            th2.join();
            Instant finish1=ct.getFinish();
            Instant finish2=ct2.getFinish();
            long timeElapsed1 = Duration.between(start, finish1).toNanos();
            long timeElapsed2 = Duration.between(start, finish2).toNanos();
            long timeElapsed=max(timeElapsed2,timeElapsed1);
//            System.out.println(timeElapsed1+" "+timeElapsed2);
            System.out.println(timeElapsed/1000000.0 + " ms to find an element using 2 threads");
            return timeElapsed/1000000.0;
        }
        else {
            Instant fin=Instant.now();
            long timeElapsed=Duration.between(st1, fin).toNanos();
            System.out.println(timeElapsed/1000000.0 + " ms to find an element using 2 threads");
            return timeElapsed/1000000.0;

        }

    }
    private static Double search4thread(Tree tree1, int searchNum, ArrayList<Integer> randomArray3) throws InterruptedException {
        Instant st1=Instant.now();
        int t1=tree1.getNode(0).getVal();
        int t2=tree1.getNode(1).getVal();
        int t3=tree1.getNode(2).getVal();
        if(t1!=searchNum && t2!=searchNum && t3!=searchNum){
            CreateTree ct=new CreateTree(tree1,randomArray3,3,false);
            CreateTree ct2=new CreateTree(tree1,randomArray3,4,false);
            CreateTree ct3=new CreateTree(tree1,randomArray3,5,false);
            CreateTree ct4=new CreateTree(tree1,randomArray3,6,false);
            ct.setSearchable(searchNum);
            ct2.setSearchable(searchNum);
            ct3.setSearchable(searchNum);
            ct4.setSearchable(searchNum);
            Thread th1=new Thread(ct);
            Thread th2=new Thread(ct2);
            Thread th3=new Thread(ct3);
            Thread th4=new Thread(ct4);
            Instant start=Instant.now();
            th1.start();
            th2.start();
            th3.start();
            th4.start();
            th1.join();
            th2.join();
            th3.join();
            th4.join();
            Instant finish1=ct.getFinish();
            Instant finish2=ct2.getFinish();
            Instant finish3=ct3.getFinish();
            Instant finish4=ct4.getFinish();
            long timeElapsed1 = Duration.between(start, finish1).toNanos();
            long timeElapsed2 = Duration.between(start, finish2).toNanos();
            long timeElapsed3 = Duration.between(start, finish3).toNanos();
            long timeElapsed4 = Duration.between(start, finish4).toNanos();
            long timeElapsed=max(max(timeElapsed2,timeElapsed1),max(timeElapsed3,timeElapsed4));
//            System.out.println(timeElapsed1+" "+timeElapsed2+" "+timeElapsed3+" "+timeElapsed4);
            System.out.println(timeElapsed/1000000.0 + " ms to find an element using 4 threads");

            return timeElapsed/1000000.0;
        }
        else {
            Instant fin = Instant.now();
            long timeElapsed = Duration.between(st1, fin).toNanos();
            System.out.println(timeElapsed / 1000000.0 + " ms to find an element using 4 threads");
            return timeElapsed / 1000000.0;
        }
    }

    private static Double run2threads(ArrayList<Integer> randomArray1,Tree t,int len) throws InterruptedException {
        Node n0=new Node(randomArray1.get(0),1,2);
        t.setNode(n0,0);
        CreateTree ct=new CreateTree(t,randomArray1,1,true);
        CreateTree ct2=new CreateTree(t,randomArray1,2,true);
        Thread th2=new Thread(ct2);
        Thread th=new Thread(ct);
        Instant start = Instant.now();
        th.start();
        th2.start();
        th.join();
        th2.join();
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toNanos();
        int h= t.getHeight(0);
        System.out.println(timeElapsed/1000000.0 + " ms to create a balanced tree of size "+len+" with 2 threads with height: "+h);
//        t.printA();
        sleep(1000);
        return timeElapsed/1000000.0;
    }
    private static Double run4threads(ArrayList<Integer> randomArray1, Tree t, int len) throws InterruptedException {
        Node n0=new Node(randomArray1.get(0),1,2);
        Node n1=new Node(randomArray1.get(1),3,4);
        Node n2=new Node(randomArray1.get(2),5,6);
        t.setNode(n0,0);
        t.setNode(n1,1);
        t.setNode(n2,2);
        CreateTree ct=new CreateTree(t,randomArray1,3,true);
        CreateTree ct2=new CreateTree(t,randomArray1,4,true);
        CreateTree ct3=new CreateTree(t,randomArray1,5,true);
        CreateTree ct4=new CreateTree(t,randomArray1,6,true);
        Thread th=new Thread(ct);
        Thread th2=new Thread(ct2);
        Thread th3=new Thread(ct3);
        Thread th4=new Thread(ct4);
        Instant start = Instant.now();
        th.start();
        th2.start();
        th3.start();
        th4.start();
        th.join();
        th2.join();
        th3.join();
        th4.join();
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toNanos();
        int h= t.getHeight(0);
        System.out.println(timeElapsed/1000000.0 + " ms to create a balanced tree of size "+len+" with 4 threads with height: "+h);
//        t.printA();
        sleep(1000);
        return timeElapsed/1000000.0;
    }
    private static Double run1threads(ArrayList<Integer> randomArray1, Tree t, int len) throws InterruptedException {
        CreateTree ct=new CreateTree(t,randomArray1,0,true);
        Thread th=new Thread(ct);
        Instant start = Instant.now();
        th.start();
        th.join();
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toNanos();
        int h= t.getHeight(0);
        System.out.println(timeElapsed/1000000.0 + " ms to create a balanced tree of size "+len+" with 1 threads with height: "+h);
//        t.printA();
        sleep(1000);
        return timeElapsed/1000000.0;
    }
}