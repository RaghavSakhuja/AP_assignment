package rag.sakhuja;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SortArrs<T> {
        private ArrayList<ArrayList<T>> Arrs;
        SortArrs(){
            Arrs= new ArrayList<>();
        }

        public void  addArr(ArrayList<T> cg) {
            ArrayList<T> t=new ArrayList<T>();
            for(int i=0;i<cg.size();i++){
                T d=cg.get(i);
                t.add(d);
            }
            Arrs.add(t);
        }

        public void DumpArrs(String Filename) throws IOException {
            PrintWriter out=null;
            try{
                out=new PrintWriter( new FileWriter(Filename));
                for(int i=0;i<Arrs.size();i++){
                    out.println(Arrs.get(i));
                }
            } finally {
                if(out!=null){
                    out.close();
                }
            }

        }
    }


