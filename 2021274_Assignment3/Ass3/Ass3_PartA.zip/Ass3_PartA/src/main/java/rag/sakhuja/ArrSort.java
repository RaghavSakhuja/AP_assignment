package rag.sakhuja;

import java.util.ArrayList;
import java.util.Collections;

public class ArrSort<T extends Comparable> implements Runnable{
    private ArrayList<T> CG;

    ArrSort(ArrayList<T> cg){
        this.CG=cg;
    }
    public ArrayList<T> getCG() {
        return this.CG;
    }
    @Override
    public void run() {
        int l= CG.size();
        boolean s=false;
        while (!s){
            s=true;
            for(int i=0;i<l-1;i+=2){
                T a=CG.get(i);
                T b=CG.get(i+1);
//                System.out.println(a+" "+b+" "+a.compareTo(b)+" o");
                if(a.compareTo(b) < 0){
//                    System.out.println("went in odd "+i+" "+a+" "+b);
                    Collections.swap(CG,i,i+1);
                    s=false;
                    }
                }
//            System.out.println("odd ended");
            for(int i=1;i<l-1;i+=2){
                T a=CG.get(i);
                T b=CG.get(i+1);
//                System.out.println(a+" "+b+" "+a.compareTo(b)+" e");
                if(a.compareTo(b) < 0){
//                    System.out.println("went in even "+i+" "+a+" "+b);
                    Collections.swap(CG,i,i+1);
                    s=false;
                    }
                }
        }
//        System.out.println(CG+" after "+l);
    }
}
