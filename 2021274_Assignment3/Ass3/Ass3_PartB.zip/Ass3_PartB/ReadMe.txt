Part_B

Raghav Sakhuja
2021274

Documentation

How to run:

pom.xml file would be available in the Ass3_PartB folder.

Import the maven project and execute the main class in Ass3_PartB/src/main/java/rag.sakhuja .

Output:

Running the code would give the required outputs.
It is recommended to reduce the background process as much as possible and run the code multiple times to get the idea of general trend of output and randomness in input generation and background can result in varied values.
The trace file called trace.txt will be generated and stored in the Ass3_partB folder.

Explanations:

The code handles a Tree with a generic Node which is created with and without parallelization using 1,2 and 4 threads. Ie only a single thread is used for non-parallel(sequential) execution.
The actual time difference is only visible for larger arrays as the overhead of creating threads might be larger than the time they save.
I have run the test cases for trees of size 10,10^3,10^5,10^6 to actually show the time variations as for 10^4 and lower is non-significant.
