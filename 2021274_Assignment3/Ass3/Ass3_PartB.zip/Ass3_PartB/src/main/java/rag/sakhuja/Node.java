package rag.sakhuja;

public class Node<T> {
    private T value;
    private int left;
    private int right;

    Node(T val,int left,int right){
        this.left=left;
        this.right=right;
        this.value=val;
    }

    @Override
    public String toString() {
        return ""+value;
    }

    public int getleft() {
        return left;
    }

    public int getright() {
        return right;
    }

    public T getVal() {
        return value;
    }
}
