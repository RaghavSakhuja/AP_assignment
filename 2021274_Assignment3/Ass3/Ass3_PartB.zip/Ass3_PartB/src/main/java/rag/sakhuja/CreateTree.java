package rag.sakhuja;

import java.time.Instant;
import java.util.ArrayList;

public class CreateTree implements Runnable{
    private Tree T;
    private ArrayList<Integer> nums;
    private int end;
    private int start;
    private boolean isCreate;
    private int Searchable;
    private boolean isFound;
    private Instant finish;

    CreateTree(Tree t,ArrayList<Integer> n,int start,boolean isCreate){
        nums=n;
        T=t;
        this.start=start;
        end=nums.size();
        this.isCreate=isCreate;
        isFound=false;
    }
    public void setSearchable(int val){
        Searchable=val;
    }
    private void addition(int current){
        if(current<end){
            Node<Integer> n=new Node(nums.get(current),2*current+1,2*current+2);
            T.setNode(n,current);
            addition(n.getleft());
            addition(n.getright());
        }
    }

    @Override
    public void run() {
        if(isCreate){
            addition(start);
        }
        else{
            search(start);
            if (!isFound){
                finish=Instant.now();
            }
        }
    }
    public Instant getFinish(){
        return finish;
    }

    private void search(int start) {
        if(start<end && !isFound){
            if(Searchable==T.getNode(start).getVal()){
                isFound=true;
                finish=Instant.now();
            }
            else{
                search(T.getNode(start).getleft());
                search(T.getNode(start).getright());
            }
        }
    }
}
