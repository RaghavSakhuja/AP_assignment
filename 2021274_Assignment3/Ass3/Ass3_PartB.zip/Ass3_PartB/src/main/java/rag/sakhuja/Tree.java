package rag.sakhuja;

import java.util.ArrayList;

import static java.lang.Math.max;

public class Tree {
    private ArrayList<Node<Integer>> initialValues;
    Tree(int len){
        initialValues=new ArrayList<Node<Integer>>(len);
        for(int i=0;i<len;i++){
            initialValues.add(null);
        }
    }
//    public int getLenght() {
//        return (initialValues.size()-threadNum)/threadNum+1;
//    }

    public void setNode(Node n,int idx) {
        initialValues.set(idx,n);
    }

    public void printA() {
        System.out.println(initialValues);
    }
    public int getHeight(int a){
        if(a>=initialValues.size()){
            return 0;
        }
        return 1+max(getHeight(initialValues.get(a).getleft()),getHeight(initialValues.get(a).getright()));
    }


    @Override
    public String toString() {
        return ""+initialValues;
    }

    public Node<Integer> getNode(int i) {
        return initialValues.get(i);

    }
}
